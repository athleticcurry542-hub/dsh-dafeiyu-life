#!/usr/bin/env python3
"""favops.py —— 「刷B站」的收藏边车（宿主直接调，不经过 MCP，模型拿不到这只手）

用法：
  python favops.py folders            # 列收藏夹 → 末行 JSON {"ok":true,"folders":[{id,title,count}]}
  python favops.py add <bvid> <fid>   # 收藏 → {"ok":true} / {"ok":false,"error":"..."}
"""
import asyncio
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 凭证找两处：优先**当前工作目录**（宿主 spawn 时 cwd = 插件家，凭证就在那儿），
# 退回脚本旁边（脚本被铺到插件家后两者一致）
CRED_CANDIDATES = [
    os.path.join(os.getcwd(), 'bili_credential.json'),
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bili_credential.json'),
]
CRED_FILE = next((p for p in CRED_CANDIDATES if os.path.exists(p)), CRED_CANDIDATES[0])


def out(obj):
    print(json.dumps(obj, ensure_ascii=False))
    sys.exit(0)


def load():
    from bilibili_api import Credential
    if not os.path.exists(CRED_FILE):
        out({'ok': False, 'error': '还没扫码登录（bili_credential.json 不存在）'})
    d = json.load(open(CRED_FILE, encoding='utf-8'))
    return Credential(
        sessdata=d['sessdata'],
        bili_jct=d['bili_jct'],
        buvid3=d.get('buvid3', ''),
        dedeuserid=str(d['dedeuserid']),
    ), int(d['dedeuserid'])


async def folders():
    from bilibili_api import favorite_list
    cred, uid = load()
    res = await favorite_list.get_video_favorite_list(uid, credential=cred)
    items = (res or {}).get('list') or []
    out({'ok': True, 'folders': [{'id': it.get('id'), 'title': it.get('title'), 'count': it.get('media_count', 0)} for it in items]})


async def add(bvid, fid):
    if os.path.exists(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".bili-duty-paused")):
        out({"ok": False, "error": "大肥鱼总开关已关闭，拒绝收藏"})
    """使用 bilibili-api-python 17.x 的 Video.set_favorite 接口。

    不再调用不存在的 favorite_list.FavoriteListResource；发送结果不等于最终页面可见。
    """
    from bilibili_api import video as ba_video
    if not isinstance(bvid, str) or not __import__('re').fullmatch(r'BV[0-9A-Za-z]{10}', bvid):
        out({'ok': False, 'error': 'BV 号不合法', 'kind': 'input'})
    if int(fid) <= 0:
        out({'ok': False, 'error': '收藏夹 ID 不合法', 'kind': 'input'})
    cred, _ = load()
    v = ba_video.Video(bvid=bvid, credential=cred)
    try:
        result = await v.set_favorite(add_media_ids=[int(fid)])
        if isinstance(result, dict) and result.get('code', 0) not in (0, None):
            out({'ok': False, 'error': 'B站拒绝收藏：' + str(result.get('message') or result['code'])[:160], 'kind': 'api'})
        out({'ok': True, 'accepted': True})
    except Exception as error:  # noqa: BLE001
        msg = str(error)
        if '已经收藏' in msg or 'already fav' in msg.lower():
            out({'ok': True, 'already': True})
        out({'ok': False, 'error': msg[:250], 'kind': 'api'})


def main():
    args = sys.argv[1:]
    if not args:
        out({'ok': False, 'error': '没有子命令（folders / add）'})
    try:
        if args[0] == 'folders':
            asyncio.run(folders())
        elif args[0] == 'add' and len(args) >= 3:
            asyncio.run(add(args[1], int(args[2])))
        else:
            out({'ok': False, 'error': '子命令不认识：' + ' '.join(args)})
    except Exception as error:  # noqa: BLE001
        out({'ok': False, 'error': str(error)[:300]})


if __name__ == '__main__':
    main()
